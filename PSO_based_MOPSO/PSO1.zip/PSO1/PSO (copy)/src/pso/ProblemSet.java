package pso;
/**
 *
 * @author  Agni Besh Chauhan - agnibeshchauhan [at] gmail [dot] com - IIT Patna, India
 */
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import static pso.PSO.PATH;

public class ProblemSet {                                
	public static final double LOW = 0;
	public static final double HIGH = 1;
	public static final double VEL_LOW = 0;
	public static final double VEL_HIGH = 1;
	public static final double ERR_TOLERANCE = 1E-20; // the smaller the tolerance, the more accurate the result, 
	public static int count =0;                       // but the number of iteration is increased
	public static Data d =new Data();
       // public static TTest t =new TTest();
	public static double evaluate(Location location,int len,int path) throws IOException {
                //System.out.println("Calculating fitnes...");
                if(count<1){
                d.Data();
                count++;
                }
		double result = 0;
                for(int i=0;i<len;i++){
                double x = Math.abs(location.getLoc()[i]); // the "x" part of the locationSystem.out.println("Calculating fitnes...");
                //System.out.println("loc:"+x);
                result = p_act(path)*x;
	    }
            
           return result;
        }
        public static double p_act(int index) throws IOException{
            //System.out.println("Calculating Pathway Activity...");
            double pa = 0;
            for(int i=1;i<PATH.get(index).size();i++){
                //System.out.println("IDX "+d.findGeneIndex(PATH.get(index).get(i)));
                int g_index =  d.findGeneIndex(PATH.get(index).get(i));
                pa += new Statistics(d.getAllSample(g_index)).getMean();
            }
            //System.out.println("tscore:"+t_score(index));
            return Math.abs(pa/Math.sqrt(PATH.get(index).size()));
        }
        public static double t_score(int index,double weight[]){
            double ts = 0;
            int missed =0;
            for(int i=1;i<PATH.get(index).size();i++){
                //if(weight[i-1]>0.4){
                int id = i-1;
                int g_index =  d.findGeneIndex(PATH.get(index).get(i));
                double mean1 = new Statistics(d.getNormalSample(g_index)).getWmean(weight,weight[id]);
                double mean2 = new Statistics(d.getTumorSample(g_index)).getWmean(weight,weight[id]);
                double stdev1 = new Statistics(d.getNormalSample(g_index)).getWstdDev(weight,weight[id]);
                double stdev2 = new Statistics(d.getTumorSample(g_index)).getWstdDev(weight,weight[id]);
                ts += (mean1-mean2)/Math.sqrt((stdev1/d.getNormalSample(g_index).length)+(stdev2/d.getTumorSample(g_index).length));
                //}
                //else{
                //missed++;
                //}
            }
            return Math.abs(ts/(PATH.get(index).size()));
        }
        
        /*public static double ranksum(int index){
            double p_value = 0.0;
            for(int i=1;i<PATH.get(index).size();i++){
                int g_index =  d.findGeneIndex(PATH.get(index).get(i));
                p_value += t.t(d.getNormalSample(g_index), d.getTumorSample(g_index));
            }
            return p_value/PATH.get(index).size();
        }*/
     /*   public static void write(){
            File out = new File("C:\\Users\\Kislay\\Desktop\\out_pros.csv");
            ArrayList<String> arr =new ArrayList<>();
            for(int x=0;x<PATH.size();x++){
                    for(int y=1;y<PATH.get(x).size();y++){
                    arr.add(PATH.get(x).get(y));
                    }
            try {
                FileWriter fw = new FileWriter(out);
                for(int m=0;m<arr.size();m++){
                    for(int n=0;n<d.getAllSample(1).length;n++){
                        int idx = d.findGeneIndex(arr.get(n));
                        fw.write((int) d.getAllSample(idx)[m]+"\t");
                    }
                    fw.write("\n");
                }
                 fw.close();
            }
              
             catch (IOException ex) {
                Logger.getLogger(PSOProcess.class.getName()).log(Level.SEVERE, null, ex);
            }
           
            }
        }*/
}
