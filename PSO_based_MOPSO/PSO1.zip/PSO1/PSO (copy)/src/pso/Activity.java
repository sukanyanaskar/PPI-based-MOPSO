/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package pso;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

/**
 *
 * @author  Agni Besh Chauhan - agnibeshchauhan [at] gmail [dot] com - IIT Patna, India
 */
public class Activity {
    
    static Data data =new Data();
    public  ArrayList<ArrayList<String>> PATH = new ArrayList<ArrayList<String>>();
   /* public static void main(String[] args) throws IOException{
      Activity a = new Activity();
      data.Data();
      a.Pathway();
      a.evo();
    }*/
    public void evo(){
    for(int i=0;i<PATH.size();i++){
    int maxIteraration =100;
    ArrayList<double[]> sample = new ArrayList<>();    
        
        
        for(int j=1;j<PATH.get(i).size();j++){
            int index=data.findGeneIndex(PATH.get(i).get(j));
            double[] allSample = data.getAllSample(index);
            sample.add(allSample); 
        }
        double zs = 0.0;
        while(maxIteraration>0){
        
        int ss=sample.size();
        double target[] = sample.get(this.random_int(0,ss));
        double r2[] = sample.get(this.random_int(0,ss));
        double r3[] = sample.get(this.random_int(0,ss));
        double r4[] = sample.get(this.random_int(0,ss));
        double mutant[] = mutate(r2,r3,r4);
        double child[] = cross(target,mutant);
        double selected[] = select(target,child);
        
        if(zscore(selected)>zs){
            zs = zscore(selected);
            //System.out.println("maxIteration"+zscore(selected)+"");
        }
        else{
            //System.out.println(" ---- ");
        }
         maxIteraration--;   
        }
        System.out.println(PATH.get(i).get(0)+"---");
        System.out.println("zScore:"+zs);
        System.out.println(" **************** ");
    }
    }
    public double[] mutate(double r2[],double r3[],double r4[]){
        double[] r5 = new double[r2.length];
        for(int i=0;i<r2.length;i++){
            double temp = r2[i]+0.5*(r3[i]+r4[i]);
            r5[i]=temp;
        }
        return r5;
    }
    public double[] cross(double[] tv, double[] mv){
        double[] cv = new double[tv.length];
        for(int i=0;i<tv.length;i++){
            double rand = myRandom(0,1);
            if(rand<0.9){
                cv[i]=mv[i];
            }
            else{
                cv[i]= tv[i];
            }
        }
        return cv;
    }
    public double[] select(double tv[], double cv[]){
        double[] sv;
        if(zscore(cv)>zscore(tv)){
            sv = cv;
        }
        else{                        
            sv = tv;
        }
       return sv;     
    }
    public double pathway_activity(double[] sample){
        double sum=0;
        for(int i=0;i<sample.length;i++){
            sum+=sample[i];
       }
        return sum*sample.length/Math.sqrt(sample.length);
    }
    public double zscore(double[] sample){
        double pa = pathway_activity(sample);
        double mean = new Statistics(sample).getMean();
        double stdev = new Statistics(sample).getStdDev();
        double score = (pa-mean)/stdev;
        
        return score;
    
    }
    
    
    
    public void Pathway() throws FileNotFoundException, IOException{
        BufferedReader br = new BufferedReader(new FileReader("C:/Users/kislay/Desktop/pathway1000.txt"));
        String str;
        int count=0;
         
        while((str = br.readLine()) !=null){
           if(str.startsWith("KEGG")){
           String[] arr = str.replace(",","").split(" ");
           PATH.add(new ArrayList<>());
           PATH.get(count).add(arr[1]);
           for(int i=6;i<arr.length-7;i++){
               PATH.get(count).add(arr[i]);
               }
           count++;
           }
        }
        
    }
    
    public String[] getPathway(int index){
        String[] array = new String[PATH.get(index).size()];
        for(int i=0;i<PATH.get(index).size();i++){
        array[i]=PATH.get(index).get(i);
        }
    return array;
    }
    public int random_int(int Min, int Max)
    {
     return (int) (Math.random()*(Max-Min))+Min;
    }   
    double myRandom(double min, double max) {
    Random r = new Random();
    return (r.nextInt((int)((max-min)*10+1))+min*10) / 100.0;
}
    
}
