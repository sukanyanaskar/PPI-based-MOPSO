package pso;

/**
 *
 * @author  Agni Besh Chauhan - agnibeshchauhan [at] gmail [dot] com - IIT Patna, India
 */

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

// this is a driver class to execute the PSO process

public class PSO {
    
    public static ArrayList<ArrayList<String>> PATH = new ArrayList<ArrayList<String>>();
    public static ArrayList<double[]> SEEDS = new ArrayList<double[]>();
    public static ArrayList<Double> PVALUE = new ArrayList<>();
    
    public static void main(String args[]) throws IOException {
        PSO.pathway();
        new PSOProcess().execute();
        new fileProcess().read();
        
        }
        
    public static void pathway() throws FileNotFoundException, IOException{
        BufferedReader br = new BufferedReader(new FileReader("C:/Users/PRATIK DUTTA/Dropbox/PhD/Btech Students/Agnibesh/datasets/pathway/child_path.txt"));
        String str;
        int count=0;
         
        while((str = br.readLine()) !=null){
           if(str.startsWith("KEGG")){
           String[] arr1 = str.split("\t");
           PVALUE.add(Double.parseDouble(arr1[4]));
           String[] arr = arr1[5].split(",");
           PATH.add(new ArrayList<>());
           PATH.get(count).add(arr1[1]);
           for(int i=0;i<arr.length;i++){
               /*if(arr[i].startsWith("0")){
                   i++;
               
               else{*/
               PATH.get(count).add(arr[i]);
               //}
               }
           count++;
           }
        }
        
    }
        
    public String[] getPathway(int index){
        String[] array = new String[PATH.get(index).size()];
        for(int i=0;i<PATH.get(index).size();i++){
        array[i]=PATH.get(index).get(i);
        }
    return array;
    }
        
}
