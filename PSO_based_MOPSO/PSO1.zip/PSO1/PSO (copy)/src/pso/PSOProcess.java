package pso;

/**
 *
 * @author  Agni Besh Chauhan - agnibeshchauhan [at] gmail [dot] com - IIT Patna, India
 */

import java.io.IOException;
import java.util.Random;
import java.util.Vector;
import static pso.PSO.PATH;
import static pso.PSO.SEEDS;

public class PSOProcess implements PSOConstants {
	private Vector<Particle> swarm = new Vector<Particle>();
	private double[] pBest = new double[SWARM_SIZE];
	private Vector<Location> pBestLocation = new Vector<Location>();
	private double gBest;
	private Location gBestLocation;
        private int PROBLEM_DIMENSION[]=new int[PATH.size()];
	private double[] fitnessValueList = new double[SWARM_SIZE];
	Random generator = new Random();
        
        
	
        public void execute() throws IOException {
            for(int a=0;a<PATH.size();a++){
            PROBLEM_DIMENSION[a]=PATH.get(a).size()-1;
            }
		
                
		for(int pa=0;pa<PATH.size();pa++){
                swarm.removeAllElements();
                double weight[] = new double[PROBLEM_DIMENSION[pa]];
                //System.out.println("psize"+PROBLEM_DIMENSION[pa]);
                initializeSwarm(PROBLEM_DIMENSION[pa]);
                updateFitnessList();
                
                //System.out.println("fsize"+fitnessValueList.length);
		for(int i=0; i<SWARM_SIZE; i++) {
			pBest[i] = fitnessValueList[i];
			//pBestLocation.add();
                        pBestLocation.add(i, swarm.get(i).getLocation());
                        //System.out.println("xxxxx"+swarm.get(i).getLocation().getLoc().length);
		}
		
		int t = 0;
		double w;
		double err = 9999;
		
                
		while(t < MAX_ITERATION && err > ProblemSet.ERR_TOLERANCE) {
			// step 1 - update pBest
                        
			for(int i=0; i<SWARM_SIZE; i++) {
                            //System.out.println("xxxxx"+fitnessValueList[i]+"xxxxx"+pBest[i]);
				if(fitnessValueList[i] < pBest[i]) {
                                    pBest[i] = fitnessValueList[i];
                                        pBestLocation.set(i, swarm.get(i).getLocation());
                                        //pBestLocation.
                                        //System.out.println("xxxxx"+pBestLocation.get(i).getLoc().length);
				}
			}
				
			// step 2 - update gBest
			int bestParticleIndex = PSOUtility.getMaxPos(fitnessValueList);
                        //System.out.println("yyyy"+fitnessValueList[bestParticleIndex]+"yyyyyy"+gBest);
			if(t == 0 || fitnessValueList[bestParticleIndex] < gBest) {
				gBest = fitnessValueList[bestParticleIndex];
                                //System.out.println("yyyy"+fitnessValueList[bestParticleIndex]+"yyyyyy"+gBest);
				gBestLocation = swarm.get(bestParticleIndex).getLocation();
			}
			
			w = W_UPPERBOUND - (((double) t) / MAX_ITERATION) * (W_UPPERBOUND - W_LOWERBOUND);
			
			for(int i=0; i<SWARM_SIZE; i++) {
				double r1 = Math.random();
                                double r2 = Math.random();
				Particle p = swarm.get(i);
				
				// step 3 - update velocity
				double[] newVel = new double[PROBLEM_DIMENSION[pa]];
                                //System.out.println("vsize"+newVel.length);
                                //System.out.println("ssize"+pBestLocation.get(i));
                                for(int v=0;v<PROBLEM_DIMENSION[pa];v++){
                                    //System.out.println("vpsize"+PROBLEM_DIMENSION[pa]);
                                    
                                    newVel[v] = (w * p.getVelocity().getPos()[v]) + (r1 * C1) * (pBestLocation.get(i).getLoc()[v]
                                            - p.getLocation().getLoc()[v]) + (r2 * C2) * (gBestLocation.getLoc()[v] - p.getLocation().getLoc()[v]);
                                    
                                }
				Velocity vel = new Velocity(newVel);
                                p.setVelocity(vel);
				
				// step 4 - update location
				double[] newLoc = new double[PROBLEM_DIMENSION[pa]];
                                for(int l=0;l<PROBLEM_DIMENSION[pa];l++){
				newLoc[l] = p.getLocation().getLoc()[l] + newVel[l];
                                }
				Location loc = new Location(newLoc);
				p.setLocation(loc);
			}
			
			err = ProblemSet.evaluate(gBestLocation,PROBLEM_DIMENSION[pa],pa) - 0; // minimizing the functions means it's getting closer to 0
			
			
		/*	System.out.println("ITERATION " + t + ": ");
                        for(int s=0;s<PROBLEM_DIMENSION[pa];s++){
			System.out.println("     D"+s+": " + gBestLocation.getLoc()[s]);
			}
			System.out.println("     Value: " + ProblemSet.evaluate(gBestLocation,PROBLEM_DIMENSION[pa]));
		*/	
			t++;
			updateFitnessList();
		}
		System.out.println(pa+". "+PATH.get(pa).get(0)+":");
		System.out.println("Solution found at iteration " + (t - 1) + ", the solutions is:");
                for(int b=0;b<PROBLEM_DIMENSION[pa];b++){
		System.out.println("     "+PATH.get(pa).get(b+1)+": "+ gBestLocation.getLoc()[b]);
                weight[b] = gBestLocation.getLoc()[b];
                SEEDS.add(pa, weight);
                }
                double tscore = ProblemSet.t_score(pa,weight);
                System.out.println("     P.A.Level: " + ProblemSet.evaluate(gBestLocation,PROBLEM_DIMENSION[pa],pa));
                System.out.println("     Tscore: " + tscore);
                //System.out.println("     P Value: " + ProblemSet.ranksum(pa));
                
        }
                        //ProblemSet.write();
	}
	
	public void initializeSwarm(int dimension) {
                //System.out.println("Initializing Swarm....");
		Particle p;
		for(int i=0; i<SWARM_SIZE; i++) {
			p = new Particle();
			
			// randomize location inside a space defined in Problem Set
			double[] loc = new double[dimension];
                        for(int l=0;l<dimension;l++){
			loc[l] = ProblemSet.LOW + Math.random() * (ProblemSet.HIGH - ProblemSet.LOW);
                        
                        }
			Location location = new Location(loc);
                        
			// randomize velocity in the range defined in Problem Set
			double[] vel = new double[dimension];
                        for(int v=0;v<dimension;v++){
			vel[v] = ProblemSet.VEL_LOW + Math.random() * (ProblemSet.VEL_HIGH - ProblemSet.VEL_LOW);
                        }
			Velocity velocity = new Velocity(vel);
			
			p.setLocation(location);
			p.setVelocity(velocity);
                        p.setLen(dimension);
                        swarm.add(p);
                        //System.out.println("Swarm Initialized"+swarm.get(i).getLocation().getLoc().length);
                        //System.out.println("Swarm Initialized");
		}
	}
	
	public void updateFitnessList() throws IOException {
                //System.out.println("Updating Fitness List....");
		for(int i=0; i<SWARM_SIZE; i++) {
                        fitnessValueList[i] = swarm.get(i).getFitnessValue();
                        }
                        //System.out.println("updated");
	}
        
        
        
}
