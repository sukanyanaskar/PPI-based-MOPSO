/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package pso;

/**
 *
 * @author Kislay
 */
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.regex.*;
import static pso.Data.GENES;
public class DiseaseAssosiation {
    
  public static void main (String[] args) throws IOException
  {   File file = new File("C:\\Users\\PRATIK DUTTA\\Dropbox\\PhD\\Btech Students\\Agnibesh\\datasets\\output\\validation\\DiseaseAssosiation\\prostate_ass.txt");
      File file2 = new File("C:\\Users\\PRATIK DUTTA\\Dropbox\\PhD\\Btech Students\\Agnibesh\\datasets\\output\\validation\\DiseaseAssosiation\\geneNames\\prostate.txt");
      FileWriter fw = new FileWriter(file2);
      BufferedReader br = new BufferedReader(new FileReader(file));
        String str;
        while ((str = br.readLine()) != null) {
        Matcher m = Pattern.compile("\\(([^)]+)\\)").matcher(str);
        while(m.find()) {
       fw.write(m.group(1)+",");    
     }
  }
        fw.close();
}
}
