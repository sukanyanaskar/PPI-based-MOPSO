package pso;
/**
 *
 * @author  Agni Besh Chauhan - agnibeshchauhan [at] gmail [dot] com - IIT Patna, India
 */
import java.io.IOException;

public class Particle {
	private double fitnessValue;
	private Velocity velocity;
	private Location location;
        private int len;
        private int pa;
	
	public Particle() {
		super();
	}

	public Particle(double fitnessValue, Velocity velocity, Location location,int len, int pa) {
		super();
		this.fitnessValue = fitnessValue;
		this.velocity = velocity;
		this.location = location;
                this.len = len;
                this.pa = pa;
	}

	public Velocity getVelocity() {
		return velocity;
	}
        
        public void setLen(int len) {
		this.len = len;
	}
        public void setPa(int pa) {
		this.pa = pa;
	}

	public void setVelocity(Velocity velocity) {
		this.velocity = velocity;
	}

	public Location getLocation() {
		return location;
	}

	public void setLocation(Location location) {
		this.location = location;
	}

	public double getFitnessValue() throws IOException {
		fitnessValue = ProblemSet.evaluate(location,len,pa);
		return fitnessValue;
	}
}
