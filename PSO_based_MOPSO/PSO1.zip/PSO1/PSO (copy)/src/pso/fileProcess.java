/*
* To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package pso;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import static pso.PSO.PATH;
import static pso.PSO.SEEDS;

/**
 *
 * @author Kislay
 */
public class fileProcess {
    Data da =new Data();
    static ArrayList<String> names = new ArrayList<>();
    public void read() throws IOException{
        //File file =new File("C:\\Users\\Kislay\\Desktop\\datasets\\pros_out.txt");
        //FileWriter fw = new FileWriter(file);
        for(int i=0;i<PATH.size();i++){
            for(int j=1;j<PATH.get(i).size();j++){
                if(SEEDS.get(i)[j-1]>=0.4){
                String s = PATH.get(i).get(j).replace("\"", "").replace(" ", "");
                if(names.contains(s)!=true){
                names.add(s);
                //fw.write(s+"\t");
                //System.out.println("---"+s+"----");
            }
            }
            }
        }
        //fw.close();
        da.Data();
        write();
        //append();
    }
    public void write() throws IOException{
        File file =new File("C:\\Users\\PRATIK DUTTA\\Dropbox\\PhD\\Btech Students\\Agnibesh\\datasets\\output\\child_final_1.txt");
        FileWriter fw = new FileWriter(file);
        for(int i=0;i<names.size();i++){
        fw.write(names.get(i)+"\t");
        //System.out.println("---"+names.get(i)+"---");
        //int n =  da.findGeneIndex(names.get(i));
        double[] arr = da.getAllSampleByName(names.get(i));
        //System.out.println(Arrays.toString(arr));
        for(int j=0;j<arr.length;j++){
            String val = arr[j]+"";
            //System.out.println(val+"****");
            fw.write(val+"\t");
            
        }
            fw.write("\n");
        }
        fw.close();
    }
    
    /*static List<String> arrayList;
    public static void append() throws IOException{
        BufferedReader in = new BufferedReader(new FileReader(new File("C:\\Users\\Kislay\\Desktop\\datasets\\prostate.txt")));
        BufferedReader in2 = new BufferedReader(new FileReader(new File("C:\\Users\\Kislay\\Desktop\\datasets\\pros_out.txt")));
        PrintWriter out = new PrintWriter(new File("C:\\Users\\Kislay\\Desktop\\datasets\\final_out.txt"));
        String[] s = null;
        String line ;
        while ((line = in.readLine())!=null){
            s = line.split("\t");
        }
        arrayList = new ArrayList<>();
        Collections.addAll(arrayList, s);
        //System.out.println(arrayList);
        String[] s2 = in2.readLine().split("\t");
        int count = 0; 
        for (int i = 0; i < s2.length; i++){
            if(help(s2[i]) == true){   
                count++;
                while ((line = in.readLine())!=null){
                    String[] parts = line.split("\t");
                    StringBuilder outLine = new StringBuilder();
                    for (int j = 0; j < parts.length; j++) {
                        if (j + 1 != i) {
                            outLine.append("\t" + parts[j]);
                        }
                    }
                    out.println(outLine.toString().trim());
                }
            }
           
        }
        out.close();
        System.out.println(count);

    }
    
    public static boolean help(String s){
      for(String ss: arrayList){
          if(ss.toLowerCase().equals(s.toLowerCase()))
              return true;
      }  
      return false;
    }*/
}
