/**
 *
 * @author  Agni Besh Chauhan - agnibeshchauhan [at] gmail [dot] com - IIT Patna, India
 */
package pso;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author Kislay
 */
public class Data {

     File file = new File("C:/Users/PRATIK DUTTA/Dropbox/PhD/Btech Students/Agnibesh/datasets/child.txt");
     public static String[] GENES = null;
     int count = 0;
     private int n_count = 0;
     private int t_count = 0;
     String[] n_values = null;
     String[] t_values = null;
     ArrayList<ArrayList<String>> data = new ArrayList<ArrayList<String>>();
     
     /*public static void main(String[] args) throws IOException{
      Data d = new Data();
      d.Data();
       //System.out.println(d.findGeneIndex("hsa04080:Neuroactive"));
    }*/
    public void Data() throws FileNotFoundException, IOException {

        BufferedReader br = new BufferedReader(new FileReader(file));
        String str;
        while ((str = br.readLine()) != null) {
            if (str.startsWith("class")) {

                GENES = str.split("\t");
                //System.out.println("GENES: "+Arrays.toString(GENES));

            }

            else if (str.startsWith("normal")) {
               // System.out.println(str);
                n_values = str.split("\t");
                data.add(new ArrayList<>());
                data.get(count).addAll(Arrays.asList(n_values));
                count++;
                n_count++;
            }
            else if (str.startsWith("tumor")) {
                //System.out.println(str);
                t_values = str.split("\t");
                data.add(new ArrayList<>());
                data.get(count).addAll(Arrays.asList(t_values));
                count++;
                t_count++;
            }

        }

    }

    public String[] getGene() {
        String[] gene = new String[GENES.length - 1];
        for (int i = 0; i < GENES.length - 1; i++) {
            gene[i] = GENES[i + 1];
        }
        return gene;
    }
    
    public int findGeneIndex(String gene){
        int geneIndex=2;
        //System.out.println(Arrays.toString(GENES));
        for(int i=1;i<GENES.length;i++){
            if(GENES[i].equalsIgnoreCase(gene)){
               geneIndex=i;
               //System.out.println(geneIndex);
            }
            
        }
         return geneIndex;
    }

   public double[] getNormalSample(int geneIndex) {
        double[] normal_sample = new double[n_count];
        for (int i = 0; i < n_count; i++) {
            normal_sample[i] = Double.parseDouble(data.get(i).get(geneIndex));
        }
        return normal_sample;
    }

    public double[] getTumorSample(int geneIndex) {
        double[] tumor_sample = new double[t_count];
        for (int i = 0; i < t_count; i++) {
            tumor_sample[i] = Double.parseDouble(data.get(i + n_count).get(geneIndex));
        }
        return tumor_sample;
    }
    public double[] getAllSample(int geneIndex) {
        double[] all_sample = new double[count];
        for (int i = 0; i < count; i++) {
            all_sample[i] = Double.parseDouble(data.get(i).get(geneIndex));
        }
        return all_sample;
    }
    
    public double[] getAllSampleByName(String name) {
        int geneIndex = findGeneIndex(name);
        double[] all_sample = new double[count];
        for (int i = 0; i < count; i++) {
            all_sample[i] = Double.parseDouble(data.get(i).get(geneIndex));
        }
        return all_sample;
    }

}
