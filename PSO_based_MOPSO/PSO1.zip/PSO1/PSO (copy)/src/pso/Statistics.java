/**
 *
 * @author  Agni Besh Chauhan - agnibeshchauhan [at] gmail [dot] com - IIT Patna, India
 */

package pso;

import java.util.Arrays;

/**
 *
 * @author Kislay
 */
public class Statistics 
{
    double[] data;
    int size;   

     Statistics(double[] data) 
    {
        this.data = data;
        size = data.length;
    }   

   
    double getMean()
    {
        double sum = 0.0;
        for(double a : data)
            sum += a;
        return sum/size;
    }
    
    double getWmean(double[] weight, double w_value){
        double w_sum =0.0;
        for(double w : weight){
            w_sum+=w;
        }
        double sum = 0.0; 
        for(double a : data){
            sum += a*w_value;
        }
            return sum/w_sum;
    }

    double getVariance()
    {
        double mean = getMean();
        double temp = 0;
        for(double a :data)
            temp += (a-mean)*(a-mean);
        return temp/size;
    }

    double getStdDev()
    {
        return Math.sqrt(getVariance());
    }
    
    double getWstdDev(double[] weight, double w_value)
    {   
        double w_sum =0.0;
        for(double w : weight){
            w_sum+=w;
        }
        double mean = getMean();
        double temp = 0;
        for(double a :data)
            temp += w_value*((a-mean)*(a-mean));
        return Math.sqrt(temp/(((weight.length-1)*w_sum)/weight.length));
        
    }

    public double median() 
    {
       Arrays.sort(data);

       if (data.length % 2 == 0) 
       {
          return (data[(data.length / 2) - 1] + data[data.length / 2]) / 2.0;
       } 
       else 
       {
          return data[data.length / 2];
       }
    }
}