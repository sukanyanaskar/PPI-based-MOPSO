
# coding: utf-8

# In[1]:


# FUNCTION TO UPDATE PERSONAL BEST OF PARTICLES IN THE POPULATION

import random
from math import *
import numpy
import copy


def update_pBest(SWARM_SIZE,no_of_obj_func,PARTICLE_FIT,pBestFitness,COUNT,pBestPosition,PARTICLE_VAL):
    summ=0
    for i in range(SWARM_SIZE):
        summ=0 
        if((PARTICLE_FIT[i][0]<pBestFitness[i][0]) and (PARTICLE_FIT[i][1]<pBestFitness[i][1]) and (PARTICLE_FIT[i][2]>pBestFitness[i][2])):
            summ+=no_of_obj_func
        elif((PARTICLE_FIT[i][0]>pBestFitness[i][0]) and (PARTICLE_FIT[i][1]>pBestFitness[i][1]) and (PARTICLE_FIT[i][2]<pBestFitness[i][2])):
            summ=0
        else:
            summ=1
        if(summ==no_of_obj_func):
            measure=0
        else:
            if(summ==0):
                measure=1
            else:
                measure=random.randint(0,1)
        if(measure==0):
            for j in range(no_of_obj_func):
                pBestFitness[i][j]=PARTICLE_FIT[i][j]
            for j in range(COUNT):
                pBestPosition[i][j]=PARTICLE_VAL[i][j]

