
# coding: utf-8

# In[1]:


# FUNCTION TO CALCULATE FITNESS VALUES OF PARTICLES IN POPULATION

import nbimporter
import random
import WEIGHTED_T_SCORE
import WEIGHTED_Z_SCORE
import INTERACTION_SCORE
reload(WEIGHTED_T_SCORE)
reload(WEIGHTED_Z_SCORE)
reload(INTERACTION_SCORE)


def update_particle(PARTICLE_FIT,no_of_obj_function,POP_SIZE, filepath, pathway_file):
    T_SCORE=WEIGHTED_T_SCORE.Weighted_T_Score(POP_SIZE, filepath, pathway_file) 
    Z_SCORE=WEIGHTED_Z_SCORE.Weighted_Z_Score(POP_SIZE, filepath, pathway_file)
    I_SCORE=INTERACTION_SCORE.Interaction_Score(POP_SIZE, pathway_file)
    for i in range(int(POP_SIZE)):
        PARTICLE_FIT[i][0]=T_SCORE[i]
        PARTICLE_FIT[i][1]=Z_SCORE[i]
        PARTICLE_FIT[i][2]=I_SCORE[i]
        
    return(PARTICLE_FIT)
            

