
# coding: utf-8

# In[2]:


# FUNCTION TO CALCULATE THE INTERACTION SCORE OF EACH PARTICLE IN THE POPULATION

import random
from math import *
import copy
from itertools import combinations

def interaction_score(POPULATION_SIZE,no_of_pathways,SUM):
    DEG_OF_RELEVANCE=[random.uniform(0,1) for i in range(no_of_pathways)] # set degree of relevance of each pathway
    WEIGHTED_SUM=0.0
    WEIGHTED_VAL=0.0
    for i in range(no_of_pathways):
        SUM[i]=SUM[i]*DEG_OF_RELEVANCE[i]
        WEIGHTED_SUM+=SUM[i]
        WEIGHTED_VAL+=DEG_OF_RELEVANCE[i]
        
    return(WEIGHTED_SUM/WEIGHTED_VAL)
        
    
        
#if __name__=='__main__':
def Interaction_Score(POPULATION_SIZE, pathway_file):
    no_of_pathways=0
    NO_OF_GENES = []
    arr1=[]
    GENES_IN_PARTICLE=0
    with open(pathway_file) as br:
        for line in br:
            if(line.startswith("KEGG")):
                no_of_pathways+=1
       
    GENES=[[] for j in range(no_of_pathways)]
    i=0
                
    with open(pathway_file) as br:
        for line in br:
            if(line.startswith("KEGG")):
                arr1=line.split('\t')
                GENES[i]=arr1[5].split(", ")
                NO_OF_GENES.append(len(GENES[i]))
                GENES_IN_PARTICLE+=len(GENES[i])
                i+=1
                
    #print NO_OF_GENES
    arr2=[]
    arr3=[]
    UNI_GENES=[[[] for j in range(NO_OF_GENES[i])] for i in range(no_of_pathways)]
    i=0
    j=0
    with open("dataset/GENES_UNIPROTKB_ID.txt") as am:
        for line in am:
            arr2=line.split("\t\t")
            arr3=arr2[1].split("\n")
            UNI_GENES[i][j]=arr3[0]
            if(j<(NO_OF_GENES[i]-1)):
                i=i
                j=j+1
            elif(j==NO_OF_GENES[i]-1):
                i+=1
                j=0
                
    UNI_GENES_PAIR=[[] for i in range(no_of_pathways)]
    for i in range(no_of_pathways):
        UNI_GENES_PAIR[i]=list(combinations(UNI_GENES[i],2))
    NO_OF_PAIR=[(len(UNI_GENES_PAIR[i])) for i in range(no_of_pathways)]
    for i in range(no_of_pathways):
        for j in range(NO_OF_PAIR[i]):
            UNI_GENES_PAIR[i][j]=list(UNI_GENES_PAIR[i][j])
    #print (UNI_GENES_PAIR[0][0][1])
    
    count=0
    with open("dataset/H_sapiens_interaction_output.txt") as am:
        for line in am:
            count+=1
    #print count
    
    ALL_GENES=[[] for i in range(count)]
    i=0
    with open("dataset/H_sapiens_interaction_output.txt") as am:
        for line in am:
            ALL_GENES[i]=line.split("\t")
            ALL_GENES[i][4]=ALL_GENES[i][4][:-2]
            i+=1
    #print ALL_GENES[10]
    
    SUM=[float(0.0) for i in range(no_of_pathways)]
    for i in range(no_of_pathways):
        for j in range(NO_OF_PAIR[i]):
            for k in range(count):
                if((UNI_GENES_PAIR[i][j][0]==ALL_GENES[k][0] and UNI_GENES_PAIR[i][j][1]==ALL_GENES[k][1]) | (UNI_GENES_PAIR[i][j][0]==ALL_GENES[k][1] and UNI_GENES_PAIR[i][j][1]==ALL_GENES[k][0])):
                    #print UNI_GENES_PAIR[i][j][0],"\t",UNI_GENES_PAIR[i][j][1],"\t",ALL_GENES[k][0],"\t",ALL_GENES[k][1]
                    SUM[i]+=float(ALL_GENES[k][4])
#     POPULATION_SIZE=10
    
    INTERACTION_SCORE=[[] for i in range(POPULATION_SIZE)]
    
    for i in range(POPULATION_SIZE):
        Sum=copy.copy(SUM)
        INTERACTION_SCORE[i]=interaction_score(POPULATION_SIZE,no_of_pathways,SUM)
        SUM=copy.copy(Sum)
#     print INTERACTION_SCORE
    return(INTERACTION_SCORE)
        
            
            
    
        
    
        
        
   
        
    

