
# coding: utf-8

# In[2]:


# FUNCTION TO INITIALISE POSITION OF PARTICLES IN POPULATION

import random
from math import *
import numpy

def initialise_PARTICLE_VALUES(COUNT,SWARM_SIZE):
    xmin=-5.12
    xmax=5.12
    initial=[[abs(xmin+random.uniform(0,1)*(xmax-xmin)) for j in range(COUNT)] for i in range(SWARM_SIZE)]
    return(initial)

