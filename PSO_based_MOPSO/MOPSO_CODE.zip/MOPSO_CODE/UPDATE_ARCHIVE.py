
# coding: utf-8

# In[4]:


# FUNCTION TO INSERT NEW NON DOMINATED PARTICLES FROM POPULATION TO ARCHIVE

import random
from math import *
import numpy
import copy
import nbimporter
import CHECK_NONDOMINATED_SOLUTION
import CROWDING
reload(CROWDING)
reload(CHECK_NONDOMINATED_SOLUTION)




def update_archive(SWARM_SIZE,no_of_nondom_sol,archive_size,COUNT,ARCHIVE_VAL,PARTICLE_VAL,ARCHIVE_FIT,PARTICLE_FIT,no_of_obj_func):
    i=0
    for k in range(SWARM_SIZE):
        archive_temp=[int(no_of_nondom_sol) for j in range(1)]
        # if particle in population is non dominated 
        if(CHECK_NONDOMINATED_SOLUTION.check_nondom(k,archive_temp,no_of_obj_func,ARCHIVE_FIT,PARTICLE_FIT,COUNT,ARCHIVE_VAL)==1):
            no_of_nondom_sol=int(archive_temp[0])
            if(no_of_nondom_sol < archive_size): # if archive memory is not full insert particle
                i=no_of_nondom_sol 
                for j in range(COUNT):
                    ARCHIVE_VAL[i][j]=PARTICLE_VAL[k][j]
                for j in range(no_of_obj_func):
                    ARCHIVE_FIT[i][j]=PARTICLE_FIT[k][j]
                no_of_nondom_sol+=1
            else: # if memory is full , select particle to replace
                # compute crowding distances of particles in archive
                no_of_nondom_sol=CROWDING.crowding_distance(no_of_nondom_sol,no_of_obj_func,COUNT,ARCHIVE_FIT,ARCHIVE_VAL)
                bottom=(no_of_nondom_sol-1)*0.90
                i=random.randint(bottom,no_of_nondom_sol-1)
                # insert new particles in archive
                for j in range(COUNT):
                    ARCHIVE_VAL[i][j]=PARTICLE_VAL[k][j]
                for j in range(no_of_obj_func):
                    ARCHIVE_FIT[i][j]=PARTICLE_FIT[i][j]
    return(no_of_nondom_sol)
    

