
# coding: utf-8

# In[2]:


# FUNCTION TO INSERT NONDOMINATED PARTICLES FROM POPULATION INTO ARCHIVE

import nbimporter
import random
from math import *
import copy
import numpy
import DELETE_PARTICLE
import CROWDING
reload(CROWDING)
reload(DELETE_PARTICLE)


def initialise_nondom_sol(no_of_nondom_sol,SWARM_SIZE,ARCHIVE_VAL,ARCHIVE_FIT,PARTICLE_VAL,PARTICLE_FIT,no_of_obj_func,archive_size,COUNT):
    flag=0
    for i in range(SWARM_SIZE):
        if(no_of_nondom_sol==0): # if archive is empty
            # insert nondominated solution from population into archive
            for j in range(COUNT):
                ARCHIVE_VAL[no_of_nondom_sol][j]=PARTICLE_VAL[i][j]
            for j in range(no_of_obj_func):
                ARCHIVE_FIT[no_of_nondom_sol][j]=PARTICLE_FIT[i][j]
            no_of_nondom_sol+=1
        else: # if archive is not empty
            flag=1
            for k in range(no_of_nondom_sol):
                total=0
                # check for non domination
                for j in range(no_of_obj_func):
                    if(((PARTICLE_FIT[i][j] < ARCHIVE_FIT[k][j]) and (j==0 | j==1)) or ((PARTICLE_FIT[i][j] > ARCHIVE_FIT[k][j]) and (j==2))):
                        total +=1;
                    if(total==no_of_obj_func): # if particle in population dominates
                    # delete particle in archive
                        no_of_nondom_sol=DELETE_PARTICLE.delete_particle(k,no_of_obj_func,no_of_nondom_sol,ARCHIVE_FIT)
                    elif(total==0): # particle in archive dominates
                        flag=0
                        break
            
            if(flag==1):
                if(no_of_nondom_sol < archive_size):# if archive memory is not full , insert particle
                    for j in range(COUNT):
                        ARCHIVE_VAL[no_of_nondom_sol][j]=PARTICLE_VAL[i][j]
                    for j in range(no_of_obj_func):
                        ARCHIVE_FIT[no_of_nondom_sol][j]=PARTICLE_FIT[i][j]
                    no_of_nondom_sol+=1
                else: # if archive memory is full , select particle to replace
                    # compute crowding distance values for particles in archive
                    no_of_nondom_sol=CROWDING.crowding_distance(no_of_nondom_sol,no_of_obj_func,COUNT,ARCHIVE_FIT,ARCHIVE_VAL)
                    temp=(no_of_nondom_sol-1)*0.90
                    k=random.randint(int(temp),no_of_nondom_sol-1)
                    for j in range(COUNT):
                        ARCHIVE_VAL[k][j]=PARTICLE_VAL[i][j]
                    for j in range(no_of_obj_func):
                        ARCHIVE_FIT[k][j]=PARTICLE_FIT[i][j] 
            
    return(no_of_nondom_sol)

                
                    
                    
                    

    
                
            

