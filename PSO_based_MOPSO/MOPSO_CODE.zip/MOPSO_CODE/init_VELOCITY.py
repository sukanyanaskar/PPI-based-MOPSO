
# coding: utf-8

# In[47]:


# FUNCTION TO INITIALISE VELOCITY OF PARTICLES IN POPULATION

import random
from math import *
import numpy


def initialise_velocity(COUNT,SWARM_SIZE):
    xmin=-5.12
    xmax=5.12
    vmin=0.25*xmin
    vmax=0.25*xmax
    init=[[(vmin+random.uniform(0,1)*(vmax-vmin)) for j in range(COUNT)] for i in range(SWARM_SIZE)]
    return(init)

