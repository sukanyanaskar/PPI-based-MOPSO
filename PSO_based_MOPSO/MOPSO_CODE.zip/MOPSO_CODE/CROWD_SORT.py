
# coding: utf-8

# In[2]:


# FUNCTION TO SORT CROWDING DISTANCE VALUES 

import random
from math import *
import copy
import numpy
import nbimporter
import CROWD_SORT
reload(CROWD_SORT)


def sort_crowd(begin,lastpart,no_of_obj_func,COUNT,ARCHIVE_FIT,ARCHIVE_VAL,CrowdList):
    l=begin+1
    r=lastpart
    turn=CrowdList[begin]
    flagF=[[] for i in range(no_of_obj_func)]
    flagP=[[] for i in range(COUNT)]
    while(l<r):
        if(CrowdList[l]<=turn):
            l+=1
        else:
            r-=1
            # swap the crowding distance values
            temp=CrowdList[l]
            CrowdList[l]=CrowdList[r]
            CrowdList[r]=temp
            # swap fitness values of two particles in the archive
            for k in range(no_of_obj_func):
                flagF[k]=ARCHIVE_FIT[l][k]
                ARCHIVE_FIT[l][k]=ARCHIVE_FIT[r][k]
                ARCHIVE_FIT[r][k]=flagF[k]
            # swap position values of two particles in the archive    
            for k in range(COUNT):
                flagP[k]=ARCHIVE_VAL[l][k]
                ARCHIVE_VAL[l][k]=ARCHIVE_VAL[r][k]
                ARCHIVE_VAL[r][k]=flagP[k]
           
    return(lastpart)
#     #swap fitness values of two particles in the archive
#     for k in range(no_of_obj_func):
#         flagF[k]=ARCHIVE_FIT[begin][k]
#         ARCHIVE_FIT[begin][k]=ARCHIVE_FIT[l][k]
#         ARCHIVE_FIT[l][k]=flagF[k]
#      # swap position values of two particles in the archive 
#     for k in range(COUNT):
#         flagP[k]=ARCHIVE_VAL[begin][k]
#         ARCHIVE_VAL[begin][k]=ARCHIVE_VAL[l][k]
#         ARCHIVE_VAL[l][k]=flagP[k]
#     # swap their crowding distance values
#     temp = CrowdList[begin];
#     CrowdList[begin] = CrowdList[l];
#     CrowdList[l] = temp;
    
#     if((l-begin)>1):
#         lastpart=CROWD_SORT.sort_crowd(begin,lastpart,no_of_obj_func,COUNT,ARCHIVE_FIT,ARCHIVE_VAL,CrowdList)
#     if((lastpart-r)>1):
#         lastpart=CROWD_SORT.sort_crowd(begin,lastpart,no_of_obj_func,COUNT,ARCHIVE_FIT,ARCHIVE_VAL,CrowdList)

