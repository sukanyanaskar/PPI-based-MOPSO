
# coding: utf-8

# In[1]:


# COMPUTE CROWDING DISTANCES OF PARTICLES IN ARCHIVE

import nbimporter
import random
from math import *
import copy
import numpy
import FITNESS_SORT
import DISTANCE_COMPUTATION
import CROWD_SORT
reload(CROWD_SORT)
reload(DISTANCE_COMPUTATION)
reload(FITNESS_SORT)


def crowding_distance(no_of_nondom_sol,no_of_obj_func,COUNT,ARCHIVE_FIT,ARCHIVE_VAL):
    CrowdList=[float(0.0) for i in range(no_of_nondom_sol)]   #initialise crowding distance values
    # objective function 1
    begin=0
    # sort fitness values
    no_of_nondom_sol=FITNESS_SORT.sort_fitness(0,begin,no_of_nondom_sol,no_of_obj_func,COUNT,ARCHIVE_FIT,ARCHIVE_VAL,CrowdList,1)
    # compute crowding distance
    no_of_nondom_sol=DISTANCE_COMPUTATION.compute_distance(0,no_of_nondom_sol,CrowdList,ARCHIVE_FIT,1)
    # objective function 2
    begin=0
    # sort fitness values
    no_of_nondom_sol=FITNESS_SORT.sort_fitness(1,begin,no_of_nondom_sol,no_of_obj_func,COUNT,ARCHIVE_FIT,ARCHIVE_VAL,CrowdList,1)
    # compute crowding distance
    no_of_nondom_sol=DISTANCE_COMPUTATION.compute_distance(1,no_of_nondom_sol,CrowdList,ARCHIVE_FIT,1)
    # objective function 3
    begin=0
    # sort fitness values
    no_of_nondom_sol=FITNESS_SORT.sort_fitness(2,begin,no_of_nondom_sol,no_of_obj_func,COUNT,ARCHIVE_FIT,ARCHIVE_VAL,CrowdList,2)
    # compute crowding distance
    no_of_nondom_sol=DISTANCE_COMPUTATION.compute_distance(2,no_of_nondom_sol,CrowdList,ARCHIVE_FIT,2)
    
    begin=0
    # sort crowding distance values
    no_of_nondom_sol=CROWD_SORT.sort_crowd(begin,no_of_nondom_sol,no_of_obj_func,COUNT,ARCHIVE_FIT,ARCHIVE_VAL,CrowdList)
    return(no_of_nondom_sol)

