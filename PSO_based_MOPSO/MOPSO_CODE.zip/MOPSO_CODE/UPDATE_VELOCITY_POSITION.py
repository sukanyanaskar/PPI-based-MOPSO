
# coding: utf-8

# In[2]:


# FUNCTION TO COMPUTE NEW VELOCITY AND POSITION FOR INDIVIDUAL PARTICLE IN POPULATION

import random
from math import *
import numpy
import copy

def update_velocity_position(no_of_nondom_sol,SWARM_SIZE,COUNT,VELOCITY,pBestPosition,PARTICLE_VAL,ARCHIVE_VAL):
    flag=(no_of_nondom_sol-1)*0.10
    for i in range(SWARM_SIZE):
        gBest=random.randint(0,int(flag))
        # compute new velocities for particles
        for j in range(COUNT):
            VELOCITY[i][j]=0.79*VELOCITY[i][j]+2.0*random.random()*(pBestPosition[i][j]-PARTICLE_VAL[i][j])+2.0*random.random()*(ARCHIVE_VAL[gBest][j]-PARTICLE_VAL[i][j])
    # compute new positions for each particle in the population
    for i in range(SWARM_SIZE):
        for j in range(COUNT):
            PARTICLE_VAL[i][j]=PARTICLE_VAL[i][j]+VELOCITY[i][j]
            
    return(no_of_nondom_sol)
            
        
    

