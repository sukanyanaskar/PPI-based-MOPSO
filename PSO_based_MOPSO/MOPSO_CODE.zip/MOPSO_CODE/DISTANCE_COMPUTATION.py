
# coding: utf-8

# In[1]:


# FUNCTION TO COMPUTE CROWDING DISTANCE NON DOMINATED PARTICLES

import random
from math import *
import copy

def compute_distance(f,no_of_nondom_sol,CrowdList,ARCHIVE_FIT,am):
    maximum=1
    minimum=1
    if(am==1):
        for i in range(1,no_of_nondom_sol-1):
            print type(ARCHIVE_FIT[i][f][0])
            CrowdList[i]=CrowdList[i]+((ARCHIVE_FIT[i+1][f])-(ARCHIVE_FIT[i-1][f]))
            if(CrowdList[minimum]>CrowdList[i]):
                minimum=i
        CrowdList[0]=CrowdList[0]+CrowdList[minimum]
        CrowdList[no_of_nondom_sol-1]=CrowdList[no_of_nondom_sol-1]+CrowdList[minimum]
        
    elif(am==2):
        for i in range(1,no_of_nondom_sol-1):
            print type(ARCHIVE_FIT[i][f])
            CrowdList[i]=CrowdList[i]+((ARCHIVE_FIT[i+1][f])-(ARCHIVE_FIT[i-1][f]))
            if(CrowdList[maximum]<CrowdList[i]):
                maximum=i
        CrowdList[0]=CrowdList[0]+CrowdList[maximum]
        CrowdList[no_of_nondom_sol-1]=CrowdList[no_of_nondom_sol-1]+CrowdList[maximum]
    
    return(no_of_nondom_sol)
        
    

