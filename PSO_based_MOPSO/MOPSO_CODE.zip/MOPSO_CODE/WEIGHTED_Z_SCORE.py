
# coding: utf-8

# In[4]:


# FUNCTION TO CALCULATE WEIGHTED Z SCORE FOR EACH PARTICLE IN THE POPULATION

import random
from math import *
import copy
import numpy


def weighted_z_score(Exp_Values,GENES_IN_PARTICLE,Expression_Values,COUNT):
    WEIGHTED_RANDOM=[(random.random()) for i in range(GENES_IN_PARTICLE)]
    FINAL_WEIGHT=0.0
    for i in range(GENES_IN_PARTICLE):
        Exp_Values[i]=Exp_Values[i] * WEIGHTED_RANDOM[i]
    FINAL_P_ACT=0.0
    for i in range(GENES_IN_PARTICLE):
        FINAL_P_ACT+=Exp_Values[i]
        FINAL_WEIGHT+=WEIGHTED_RANDOM[i]
        
    PATHWAY_ACTIVITY=FINAL_P_ACT/(FINAL_WEIGHT**0.5)
    W_MEAN=FINAL_P_ACT/FINAL_WEIGHT 
    for i in range(GENES_IN_PARTICLE):
        Expression_Values[i]=(abs(Expression_Values[i]-W_MEAN)**2)*WEIGHTED_RANDOM[i]
    #print Expression_Values
    #print PATHWAY_ACTIVITY
    Variance=0.0
    for i in range(GENES_IN_PARTICLE):
        Variance+=Expression_Values[i]
        
    W_STD_DEV=(((COUNT/(COUNT-1))*(Variance/FINAL_WEIGHT))**0.5)
    WEIGHTED_Z_SCORE=(PATHWAY_ACTIVITY-W_MEAN)/W_STD_DEV
    return(WEIGHTED_Z_SCORE)


def Weighted_Z_Score(POPULATION_SIZE, filepath, pathway_file):
    no_of_pathways=0
    NO_OF_GENES = []
    NumberOfGenes=[]
    arr1=list()
    GENES_IN_PARTICLE=0
    with open(pathway_file) as br:
        for line in br:
            if(line.startswith("KEGG")):
                no_of_pathways+=1
       
    GENES=[[] for j in range(no_of_pathways)]
    i=0
                
    with open(pathway_file) as br:
        for line in br:
            if(line.startswith("KEGG")):
                arr1=line.split('\t')
                GENES[i]=arr1[5].split(", ")
                NO_OF_GENES.append(len(GENES[i]))
                NumberOfGenes.append(len(GENES[i]))
                GENES_IN_PARTICLE+=len(GENES[i])
                i+=1
   

    NORMAL_DATA=[]
    TUMOR_DATA=[]
    n_count=0
    t_count=0
    with open(filepath) as fp:
        for line in fp:
            if(line.startswith("normal")):
                n_count+=1
            elif(line.startswith("tumor")):
                t_count+=1
       
    COUNT=n_count+t_count
    
    ALL_GENES=[]
    Total=0
    VALUES=[]
    Normal_Values=[float(0.0) for i in range(GENES_IN_PARTICLE)]
    N_Value=[float(0.0) for i  in range(GENES_IN_PARTICLE)]
    Tumor_Values=[float(0.0) for i in range(GENES_IN_PARTICLE)]
    T_Value=[float(0.0)for i in range(GENES_IN_PARTICLE)]
    g=0
    with open(filepath) as sn:
        for line in sn:
            if(line.startswith("class")):
                ALL_GENES=line.split("\t")
    #print GENES           
    for i in range(no_of_pathways):
        for j in range(NumberOfGenes[i]):
            for k in range(len(ALL_GENES)):
                if(GENES[i][j].lower()==ALL_GENES[k]):
                    with open(filepath) as am:
                        for line in am:
                            if(line.startswith("normal")):
                                VALUES=line.split("\t")
                                Normal_Values[g]+=float(VALUES[k])
                                N_Value[g]+=float(VALUES[k])
                            elif(line.startswith("tumor")):
                                VALUES=line.split("\t")
                                Tumor_Values[g]+=float(VALUES[k])
                                T_Value[g]+=float(VALUES[k])
            g+=1
    Exp_Values=[float(0.0) for i in range(GENES_IN_PARTICLE)]
    Expression_Values=[float(0.0) for i in range(GENES_IN_PARTICLE)]
    #print Normal_Values,"\n\n",Tumor_Values
    for i in range(GENES_IN_PARTICLE):
        Exp_Values[i]=Normal_Values[i]+Tumor_Values[i]
    Expression_Values=copy.copy(Exp_Values)
    #print len(Exp_Values)
    WEIGHTED_Z_SCORE=[[] for i in range(POPULATION_SIZE)]
    for p in range(POPULATION_SIZE):
        E1=copy.copy(Exp_Values)
        E2=copy.copy(Expression_Values)
        WEIGHTED_Z_SCORE[p]=weighted_z_score(Exp_Values,GENES_IN_PARTICLE,Expression_Values,COUNT)
        Exp_Values=copy.copy(E1)
        Expression_Values=copy.copy(E2) 
    return(WEIGHTED_Z_SCORE)

