
# coding: utf-8

# In[3]:


# FUNCTION TO CHECK NON DOMINATION OF PARTICLES IN POPULATION AND ARCHIVE

import random
from math import *
import numpy
import copy



def check_nondom(i,archive_temp,no_of_obj_func,ARCHIVE_FIT,PARTICLE_FIT,COUNT,ARCHIVE_VAL):
    h=0
    while(h<=int(archive_temp[0])):
        summ = 0;
        if((ARCHIVE_FIT[h][0]<PARTICLE_FIT[i][0]) and (ARCHIVE_FIT[h][1]<PARTICLE_FIT[i][1]) and (ARCHIVE_FIT[h][2]>PARTICLE_FIT[i][2])):
            summ+=no_of_obj_func   # if particle in archive dominates
            return(0)
        elif((ARCHIVE_FIT[h][0]>=PARTICLE_FIT[i][0]) and (ARCHIVE_FIT[h][1]>=PARTICLE_FIT[i][1]) and (ARCHIVE_FIT[h][2]<=PARTICLE_FIT[i][2])):
            summ=0     # if particle in archive is dominated , delete it
            for j in range(COUNT):
                ARCHIVE_VAL[h][j]=ARCHIVE_VAL[int(archive_temp[0])-1][j]
            for j in range(no_of_obj_func):
                ARCHIVE_FIT[h][j]=ARCHIVE_FIT[int(archive_temp[0])-1][j]
            archive_temp[0]-=1
        else:
            h+=1
            
    return(1)

      
   

