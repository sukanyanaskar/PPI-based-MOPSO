
# coding: utf-8

# In[4]:


# FUNCTION TO STORE PERSONAL BEST VALUES OF PARTICLES IN POPULATION 

import random
from math import *
import copy


def p_Best(pBestPosition,pBestFitness,PARTICLE_VAL,PARTICLE_FIT,SWARM_SIZE,no_of_obj_func,COUNT):
    for i in range(SWARM_SIZE): # store personal best positions of particles
        for j in range(COUNT):
            pBestPosition[i][j]=PARTICLE_VAL[i][j]
            
    for i in range(SWARM_SIZE): # store personal best fitness values of particles
        for j in range(no_of_obj_func):
            pBestFitness[i][j]=PARTICLE_FIT[i][j]
    

