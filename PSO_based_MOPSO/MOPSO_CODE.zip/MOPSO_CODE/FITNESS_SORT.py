
# coding: utf-8

# In[1]:


# FUNCTION TO SORT FITNESS VALUES OF PARTICLES IN ARCHIVE

import random
from math import *
import copy
import numpy
import nbimporter
import FITNESS_SORT
reload(FITNESS_SORT)


def sort_fitness(f,begin,lastpart,no_of_obj_func,COUNT,ARCHIVE_FIT,ARCHIVE_VAL,CrowdList,am):
    l=begin+1
    r=lastpart
    turn=ARCHIVE_FIT[begin][f]
    flagF=[[] for i in range(no_of_obj_func)]
    flagP=[[] for i in range(COUNT)]
    while(l<r):
        if(am==1):
            if(ARCHIVE_FIT[l][f]>=turn):
                l+=1
            else:
                r-=1
                # swap fitness values of two particles in the archive
                for k in range(no_of_obj_func):
                    flagF[k]=ARCHIVE_FIT[l][k]
                    ARCHIVE_FIT[l][k]=ARCHIVE_FIT[r][k]
                    ARCHIVE_FIT[r][k]=flagF[k]
                #swap positions of two particles in the archive
                for k in range(COUNT):
                    flagP[k]=ARCHIVE_VAL[l][k]
                    ARCHIVE_VAL[l][k]=ARCHIVE_VAL[r][k]
                    ARCHIVE_VAL[r][k]=flagP[k]
                # swap their crowding distances
                temp=CrowdList[l]
                CrowdList[l]=CrowdList[r]
                CrowdList[r]=temp
                
        elif(am==2):
            if(ARCHIVE_FIT[l][f]<=turn):
                l+=1
            else:
                r-=1
                # swap fitness values of two particles in the archive
                for k in range(no_of_obj_func):
                    flagF[k]=ARCHIVE_FIT[l][k]
                    ARCHIVE_FIT[l][k]=ARCHIVE_FIT[r][k]
                    ARCHIVE_FIT[r][k]=flagF[k]
                #swap positions of two particles in the archive
                for k in range(COUNT):
                    flagP[k]=ARCHIVE_VAL[l][k]
                    ARCHIVE_VAL[l][k]=ARCHIVE_VAL[r][k]
                    ARCHIVE_VAL[r][k]=flagP[k]
                # swap their crowding distances
                temp=CrowdList[l]
                CrowdList[l]=CrowdList[r]
                CrowdList[r]=temp
                
            
                
#     l-=1
#     # swap fitness values of two particles in the archive
#     for k in range(no_of_obj_func):
#         flagF[k]=ARCHIVE_FIT[begin][k]
#         ARCHIVE_FIT[begin][k]=ARCHIVE_FIT[l][k]
#         ARCHIVE_FIT[l][k]=flagF[k]
#     # swap positions of two particles in the archive
#     for k in range(COUNT):
#         flagP[k]=ARCHIVE_VAL[begin][k]
#         ARCHIVE_VAL[begin][k]=ARCHIVE_VAL[l][k]
#         ARCHIVE_VAL[l][k]=flagP[k]
#     # swap their crowding distances
#     temp = CrowdList[begin];
#     CrowdList[begin] = CrowdList[l];
#     CrowdList[l] = temp;
    
#     if(l-begin>1):
#         lastpart=FITNESS_SORT.sort_fitness(f,begin,lastpart,no_of_obj_func,COUNT,ARCHIVE_FIT,ARCHIVE_VAL,CrowdList,am)
#     if((lastpart-r)>1):
#         lastpart=FITNESS_SORT.sort_fitness(f,begin,lastpart,no_of_obj_func,COUNT,ARCHIVE_FIT,ARCHIVE_VAL,CrowdList,am)
    return(lastpart)

