
# coding: utf-8

# In[1]:


# FUNCTION TO DELETE PARTICLE IN ARCHIVE

import random
from math import *
import copy
import numpy


def delete_particle(k,no_of_obj_func,no_of_nondom_sol,ARCHIVE_FIT):
    # if infeasible particle is the last in archive or only one particle in archive
    if((no_of_nondom_sol== 1) | (k == no_of_nondom_sol-1)):
        no_of_nondom_sol-=1
    # move last particle in archive in place of infeasible particle
    else:
        for j in range(no_of_obj_func):
            ARCHIVE_FIT[k][j]=ARCHIVE_FIT[no_of_nondom_sol-1][j]
        no_of_nondom_sol-= 1;
    return(no_of_nondom_sol)
    
    

